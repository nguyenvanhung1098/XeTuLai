# Git
## 1. Git fetch
**sourse**: https://www.atlassian.com/git/tutorials/syncing/git-fetch
- Thư mục git :
    ![image](./image/gitfolder.png)

    
- Git lưu trữ các commit của local và remote tại thư mục **./.git/objects**
- ./.git/refs/heads/ lưu trữ commit nào là của branch local nào
 Xem những branch local: git branch
- ./.git/refs/remotes/ cho biết branch remote có những commit nào
 Xem những branch remote: git branch -r

- Khi thực hiện lệnh _git fetch_ :
    - Tải về tất cả những thay đổi file (commit) trên server repo vào thư mục ./git/object
    - Cập nhật file FETCH_HEAD (lưu lại từng branch tương ứng với những commit nào)
    - Cập nhật file trong thư mục refs/remotes/origin (remote)
    - File trong thư mục refs/heads không đổi (local)
    - Các file đang làm việc không bị ảnh hưởng
### 2. Git pull
- git pull = git fetch + git merge
## 2. Git rebase
- rebase là một cách để tích hợp những thay đổi từ một nhánh khác.

    Có 2 branch như sau:

    ![image](./image/2branch.png)

    Thực hiện lệnh:
    
    ```
    git checkout experiment
    git rebase master
    ```
    ![image](./image/gitrebase.png)
    
    Lấy những nhánh commit của master để làm base sau đó đưa những commit của experiment lên trước tiếp tục phát triển:

# Network
#### 1. ARP
Link tham khảo: 
https://searchnetworking.techtarget.com/definition/Address-Resolution-Protocol-ARP
https://www.fortinet.com/resources/cyberglossary/what-is-arp
https://www.auvik.com/franklyit/blog/what-is-an-arp-table/
##### 1.1. Tổng quan
- ARP là một giao thức hoặc thủ tục có chức năng tìm địa chỉ MAC vật lý từ địa chỉ IP trong mạng nội bộ.
- Công việc của ARP cơ bản là chuyển từ địa chỉ IP (v4 32 bit) -> địa chỉ MAC (48 bit).
- ARP hoạt động chủ yếu tại layer 2 và 3 trong mô hình OSI. Địa chỉ MAC tồn tại trong layer2 (datalink layer) trong khi địa chỉ IP tồn tại trong layer3 (network layer)
##### 1.2. Cách hoạt động
- Khi một máy tính mới tham gia vào mạng LAN nó sẽ được gắn cho một địa chỉ IP duy nhất để định danh và giao tiếp. 
- Khi một package đến được định sẵn cho một host trên một mạng LAN cụ thể đến một gateway. Gateway sẽ yêu cầu chương trình ARP tìm địa chỉ MAC mà match với địa chỉ IP. Một bảng được gọi là ARP cache duy trì một bản ghi của từng địa chỉ IP và địa chị MAC tương ứng của nó.
- Tất cả các OS trong một mạng IPV4 đều giữa một ARP cache. Đôi khi, 1 host yêu cầu địa chỉ MAC để gửi một packet đến 1 host khác trong mạng LAN, nó sẽ kiểm tra ARP cache của nó để xem liệu bản dịch từ địa chỉ IP sang MAC đã tồn tại hay chưa. Nếu chưa có thì yêu cầu địa chỉ mạng sẽ được gửi và ARP sẽ được thực hiện.
- ARP broadcasts là gói tin request đến tất cả các host trong LAN và hỏi có máy host nào đang sử dụng địa chỉ IP đó không. Khi một máy nhận ra địa chỉ IP là của chính nó, nó sẽ gửi trả lời để ARP có thể cập nhật bộ nhớ cache để tham khảo trong tương lai và tiếp tục giao tiếp.
- Kích thước bộ nhớ ARP cache là có giới hạn và nó sẽ được xóa định kỳ tất các các mục nhật để giải phóng dung lượng. Trong thực tế chỉ lưu lại trong vài phút. Việc cập nhật thường xuyên cho phép các thiết bị khác trong mạng có thể biết khi nào các host vật lý thay đổi địa chỉ IP.
- ARP protocol là cần thiết để kết nối giữa layer3 và layer2. Không có ARP cache ghi lại các cặp địa chỉ này, mỗi khi các thiết bị gửi gói tin cho nhau, chúng sẽ phải hỏi “Địa chỉ MAC của bạn là gì?” đến tất cả các host trong mạng. Điều này thực sự sẽ làm chậm giao tiếp mạng!
##### 1.3. Khác biệt giữa ARP table và MAC Table
- ARP table mapping giữa IP addr với MAC addr
- MAC addr table mapping giữa switchports  với MAC addr
- Routing table mapping giữa IP addr và interfaces

## DNS
Link tham khảo: http://www.firewall.cx/networking-topics/protocols/domain-name-system-dns/158-protocols-dns.html

- Các máy tính trên internet sử dụng địa chỉ IP để trao đổi dữ liệu với nhau trong mạng. Các máy tính làm việc với con số, nhưng khi người dùng sử dụng thì các con số vừa khó nhớ và khó sử dụng. Bởi vậy người ta sử dụng domain name để thay thế cho địa chỉ IP. Gắn địa chỉ IP với tên miền dễ nhớ dễ sử dụng.
-> DNS ra đời với chức năng phân giải địa chỉ từ domain name thành địa chỉ IP.
- DNS là một cơ sở dữ liệu được phân phối theo thứ bậc. Hầu hết các công ty ngày nay đều có máy chủ DNS của riêng.
- Giao thức DNS hoạt động khi máy tính của bạn gửi truy vấn DNS đến máy chủ để phân giải tên miền sang địa chỉ IP.
    Ví dụ khi nhập một tên miền trong trình duyệt web, thao tác này sẽ kích hoạt một DNS request, từ máy tính của bạn sẽ gửi đi đến DNS server yêu cầu địa chỉ IP của của website.

 
   ![image](./image/DNS_OSI.png)

- Giao thức DNS thường sử dụng UDP protocol như là một phương tiện để truyển tải vì chi phí nó nhỏ hơn TCP, và dẫn đến tốc độ nhanh hơn.
- Trong trường hợp có lỗi liên tục và  máy tính cố gắng request DNS nhưng không nhaanjn được trả lời nó sẽ chuyển sang TCP để đảm bảo dữ liệu đến không có lỗi. Tuy nhiên quá trình này còn tùy phụ thuộc vào hệ điều hành. Một số hệ điều hành không cho phép DNS sử dụng giao thức TCP. Hiếm khi gặp lỗi đến mức không thể phân giải được bất kỳ tên máy chủ hoặc tên miền nào.
- Máy chủ DNS sử dụng cổng 53 cho dịch vụ của nó. Điều này có nghĩa là một máy chủ DNS sẽ lắng nghe trên cổng 53.
- Hệ thống máy chủ DNS:
    - Máy chủ tên miền gốc (Root server)
        - Trả lời truy vấn cho các máy chủ cục bộ
        - Quản lý các zone và phân quyền quản lý cho máy chủ cấp dưới
        - Có 13 hệ thống máy chủ gốc trên mạng Internet
    - Máy chủ tên miền cấp 1 (Top Level Domain)
        - Quản lý tên miền cấp 1
    - Máy chủ được ủy quyền (Authoritative DNS servers)
        - Quản lý tên miền cấp dưới
    - Máy chủ của các tổ chức : của ISP
        - Không nằm trong phân cấp của DNS
    - Máy chủ cục bộ: dành cho các mạng nội bộ của cơ quan tổ chức
        - Không nằm trong phân cấp của DNS
    - Cơ chế mặc định trên các máy chủ DNS: 
        ![image](./image/DNS_eg.png) 

## TCP vs UDP

- TCP và UDP thực hiện trong tầng transport (TCP/IP) điều khiển truyền dữ liệu giữa các tiền trình của tầng ứng dụng.
- Các ứng dụng cần 100% độ tin cậy thì sử dụng dịch vụ của TCP như mail,...
- Các ứng dụng cần chuyển dữ liệu nhanh, có khả năng chịu lỗi , ví dụ  VoIP, Video Streaming sử dụng dịch vụ của UDP
    eg: ứng dụng và dịch vụ giao vận:

    ![image](./image/Tcp_udp.png)


# Namespace network
### 5.1. Network namespace
Link tham khảo: https://www.cloudsavvyit.com/742/what-are-linux-namespaces-and-what-are-they-used-for/
#### 5.1.1. Linux Namespace là gì 
- Linux namespace là 1 công nghệ cơ bản phía sau công nghệ container như Docker. Linux namespace là một tính năng để phân chia các tài nguyên hệ thống như một tập hợn tiến trình chỉ thấy một tập hợp tài nguyên tương ứng.
- Ví dụ PID namespace cô lập (isolate) vùng số cấp cho IP của tiến trình, có nghĩa là 2 tiến trình trên cùng một máy chủ, nhưng ở khác namespace có thể cùng ID tiến trình.
- Phân loại: Hiện tại Linux cung cấp sẵn cho người dùng 7 namespaces: 
    - Mount: Cô lập các điểm gắn kết tập tin hệ thống.
    - UTS: Cô lập hostname và domainname
    - IPC: Cô lập tài nguyên liên tiến trình (Interprocess Communication)
    - PID: Cô lập không gian số PID
    - Network: cô lập network interface
    - User: Cô lập không gian số UID/GID
    - Cgroup: Cô lập về thư mục root của tính năng Cgroups
#### 5.1.2. Network namespace
- Network namspace là khái niệm cho phép bạn cô lập môi trường mạng network trong một host. Namespace phân chia việc sử dụng các khác niệm liên quan tới network như devices, địa chỉ addresses, ports, định tuyến và các quy tắc tường lửa vào trong một hộp (box) riêng biệt, chủ yếu là ảo hóa mạng trong một máy chạy một kernel duy nhất.
- Mỗi network namespaces có bản định tuyến riêng, các thiết lập iptables riêng cung cấp cơ chế NAT và lọc đối với các máy ảo thuộc namespace đó. Linux network namespaces cũng cung cấp thêm khả năng để chạy các tiến trình riêng biệt trong nội bộ mỗi namespace. 
- Network namespace được sử dụng trong khá nhiều dự án như Openstack, Docker và Mininet.
#### 5.1.3. Tạo network namespace
- Tạo network namespace sử dụng lệnh: ```ip netns add <namespace_name>```
- Ví dụ tạo thêm 2 namespace là ns1 và ns2:
    ```
    ip netns add ns1
    ip netns add ns2
    ```
- Để xem network namespacce đã tạo sử dụng lênh: ``` ip netns list ``` 

    Minh họa kết quả khi tạo 2 network namespace

    ![image](./image/creatns.png)

- Mỗi khi thêm vào một namespace, một file mới được tạo trong thư mục /var/run/netns với tên giống như tên namespace (Không bao gồm file của root namespace). Có thể sử dụng lệnh ```ls -l /var/run/netns``` để xem.
- Để xử lý các lệnh trong một namespace (không phải root namespace) sử dụng lệnh theo cú pháp:
    ``` ip netns exec <namespace> <command>
    ```
    Tham khảo thêm: man ip netns

### 5.2. Linux bridge
Link tham khảo: https://developers.redhat.com/blog/2018/10/22/introduction-to-linux-interfaces-for-virtual-networking#bridge

- Linux bridge giống như một network switch. Nó chuyển gói tin giữa các interfaces mà kết nối với nó. Nó thường được sử dụng để fowarding packets trên routers, trên gateways, hoặc giữa các máy ảo VMs và network namespaces trên 1 máy chủ. Nó cũng hỗ trợ STP, bộ lọc VLAN và snooping đa hướng.

- Sử dụng 1 bridge khi muốn thiết lập các kênh giao tiếp giữa VMs, containers, và máy host.

    ![image](./image/switch.png)

- Đây là cách tạo 1 bridge:
    ```
    # ip link add br0 type bridge
    # ip link set eth0 master br0
    # ip link set tap1 master br0
    # ip link set tap2 master br0
    # ip link set veth1 master br0
    ```
    Tạo 1 bridge có tên là br0 và đặt 2 TAP devices (tap1, tap2), 1 VETH device (veth1), và device vật lý (eth0) làm slaves  của nó.

### 5.3. Lab
#### 5.3.1. Tóm tắt
- Lab thực hiện tạo 2 network namespace sử dụng VETH (Virtual Ethernet) và Linux bridge để cấu hình 2 network namespace sao cho:
    - Có thể ping giữa 2 namespace được với nhau
    - Có thể ping qua lại giữa 2 namespace và root namespace
    - Có thể ping ra ngoài internet từ mỗi namespace
- Link tham khảo: 
    - https://tanzu.vmware.com/developer/blog/a-container-is-a-linux-namespace-and-networking-basics/
    - https://blogd.net/linux/quan-ly-ethernet-network-bridge-tren-linux/

- Lưu ý: để có thể ping được ra internet thì cần kết nối card mạng vật lý cho host.
- Sơ đồ thực hiện:

    ![image](./image/diagram.png)

#### 5.3.1. Thực hành
- Tạo 2 namespace:
    ```
    sudo ip netns add ns1
    sudo ip netns add ns2
    ```
    Xem những namespace đã tạo bằng ```ip netns list```

    ![image](./image/create_namespace.png)

- Tạo Virtuel Ethernet Cable cho mỗi namespace
    ```
    sudo ip link add veth-ns1 type veth peer name bread-ns1-veth
    sudo ip link add veth-ns2 type veth peer name bread-ns2-veth
    ```
    Sử dụng lệnh ```ip link list``` để xem những Veth đã tạo.

- Đưa lần lượt từng đầu veth vào trong mỗi namespace:
    ```
    sudo ip link set veth-ns1 netns ns1
    sudo ip link set veth-ns2 netns ns2
    ```
    Có thể kiểm tra bằng lệnh: ```sudo ip netns exec ns1 ip link```
    
    ![image](./image/addveth.png)

- Gán địa chỉ IP cho mỗi namespace:
    Namespace ns1:
    ```
    sudo ip netns exec ns1 ip address add 192.168.51.55/24 dev veth-ns1
    sudo ip netns exec ns1 ip link set veth-ns1 up
    ```
    Namespace ns2:
    ```
    sudo ip netns exec ns2 ip address add 192.168.51.56/24 dev veth-ns2
    sudo ip netns exec ns2 ip link set veth-ns2 up
    ```
    
    Sử dụng lênh: ``` sudo ip netns exec ns1 ip addr``` để kiểm tra ip đã được gán:
    
    ![image](./image/check_add_ip.png)

- Tạo bridge và gán các port cho nó:

    ```
    # Tao bridge
    sudo ip link add name brd1 type bridge 

    # Gán interface vào ethernet bridge
    brctl addif brd1 enx000ec68ca8d3

    # Kich hoạt bridge
    sudo ip link set brd1 up

    # set up veth
    sudo ip link set bread-ns1-veth up
    sudo ip link set bread-ns2-veth up

    # add bread veth interfaces vào bridge
    sudo ip link set bread-ns1-veth master brd1
    sudo ip link set bread-ns2-veth master brd1
    
    #verify
    bridge link show brd1
    brctl show
    ```
    
    ![image](./image/check_bridge.png)

- Giờ có thể ping giữa 2 namespace 
    ```sudo ip netns exec ns1 ping 192.168.51.56```
    Kết quả:
    
    ![image](./image/ping_namespace.png)

- Kết nối đến root namespace:
    ```sudo ip addr add 192.168.51.60/24 brd + dev brd1```
    Giờ có thể ping từ các namespace mới tạo đến root namespace và ngược lại:
    ``` ping 192.168.51.56```
    
    ![image](./image/ping_namespace_root.png)

- Để ping ra internet đầu tiên phải add default gateway đến bridge:
    ``` sudo ip -all netns exec ip route add default via 192.168.51.50```

    Có thể check routing table như thế nào trong mỗi namespace sử dụng lệnh:
    ```
    sudo ip netns exec ns1 ip route
    sudo ip netns exec ns2 ip route
    ```
- Giờ có thể connect ra internet, nhưng không thể gửi hoặc nhận packets. Để nhận packets, cấu hình NAT với Masquerade. Masquerade cho phép máy truy cập internet một cách vô hình thông qua cổng Masquerade gateway, trong khi NAT có thể ản các địa chỉ private khỏi internet.
    Thêm iptables rule trong POSTROUTING chain của NAT table để nhận gói tin:
    ```
    sudo iptables -t nat -A POSTROUTING -s 192.168.51.60/24 -j MASQUERADE
    ```
    
Trong đó:
    - -t : đánh dấu các lệnh bảng được chuyển hưởng tới
    - -A : Chỉ định đang thêm một rule vào chain
    - -s : địa chỉ nguồn
    - -j : hành động đang được thực hiện
- Bật packet forwarding với IPv4 ip forwarding:
    ```sudo sysctl -w net.ipv4.ip_forward=1```

- Giờ có thể ping ra ngoài internet từ các namespace: