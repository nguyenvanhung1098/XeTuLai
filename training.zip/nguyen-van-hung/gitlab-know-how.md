# Gitlab
## 1. Tổng quan GitLab
### 1.1. Giới thiệu Gitlab
- Gitlab là server hoạt động trên Git. Gitlab ra đời năm 2015 và được cộng đồng lập trình viên đón nhận và được coi là bản nâng cấp của github.
#### 1.1.1. Lịch sử phát triển của Gitlab
- “Cha đẻ” của Gitlab là Dmitriy Zaporozhets. Ông là người Ukraine và là giám đốc điều hành Sytse Sijbrandij (trụ sử được đặt tại Utrecht). Thật ra, đây là “đứa con tinh thần” của cả một nhóm: Sid Sijbrandij, Dmitriy Zaporozhets, Key people , Sid Sijbrandij (CEO), Dmitriy Zaporozhets (CTO)

- Năm 2013, Gitlab “trình làng” với 2 phiên bản CE miễn phí (Community Editor) và EE có trả phí (Enterprise Editor). Gitlab được viết bằng ngôn ngữ Ruby với giấy phép phần mềm tự do và nguồn mở MIT. Một số phần sau đó được viết bằng ngôn ngữ Go và Vue.js.

- Tính đến thời điểm này, Gitlab đã được Alibaba Group, IBM, Spacex và Khosla Ventures, … tài trợ.

- Trung tâm nghiên cứu Jülich Research Center, NASA, Alibaba, O’Reilly Media, Leibniz-Rechenzentrum (LRZ), CERN,… và hơn 100.000 tổ chức khác đã chọn Gitlab làm nơi lưu trữ cho mình. Hiện tại, có hơn 1000 mã nguồn mở có mặt trên Gitlab.
#### 1.1.2. Các phiên bản của Gitlab
Phiên bản đặc biệt: GitLab hỗ trợ ba phiên bản:

- Gitlab community editon (CE): còn được biết đến là Gitlab phiên bản cộng đồng. Đây là phiên bản mã nguồn mở. Được cung cấp qua Git từ kho lưu trữ chứa Gitlab. Phiên bản mới nhất của Gitlab được các nhà phát triển release tại các nhánh stable và nhánh master.
- Gitlad enterprise edition (EE): còn được biết đến là Gitlab phiên bản doanh nghiệp. Đây là phiên bản có sẵn không lâu sau khi phát hành bản CE, được cung cấp từ kho lưu trữ của gitlab.com. Một doanh nghiệp đăng lý GitLab được sự support của GitLad BV những khó khăn khi cài đặt.
- Gitlab continuous intergration (CI). Đây là một giải pháp tích hợp được thực hiện bởi nhóm phát triển Gitlab.
#### 1.1.3. Lợi ích của việc sử dụng Gitlab
- Gitlab là open core: Đây là một ưu thế cạnh tranh dành cho GitLab khi các đối thủ của phần mềm này chủ yếu là các closed-source. GitLab Community Edition là mã nguồn mở hoàn chỉnh và phiên bản Enterprise Edition là open core (độc quyền).

- Truy cập vào mã nguồn: Điểm vượt trội của Open core là có thể xem và sửa đổi source code của GitLab Community Edition và Enterprise Edition khi nào bạn muốn. Điều này không thể thực hiện đối với phần mềm closed-source.

- Tính khả thi lâu dài (Viable long term): Chính vì sự uy tín của GitLab, nên đã tạo ra một cộng đồng vững chắc với hàng trăm nghìn tổ chức, cá nhân sử dụng và đóng góp cho phần mềm.
- Xây dựng với cộng đồng: Bởi những ý kiến đóng góp, xây dựng cùng sự phản hồi tích của của người dùng, GitLab đang ngày một xây dựng những phiên bản tốt nhất từ ý kiến của các khách hàng để đem đến cho họ những trải nghiệm tuyệt vời nhất. 
- Phiên bản ổn định mới mỗi tháng: GitLab phát hành phiên bản ổn định mới mỗi tháng, đầy đủ các cải tiến, tính năng và bản sửa lỗi. 
### 1.2. So sánh Gitlab và Github
[Link tham khảo:](https://usersnap.com/blog/gitlab-github/)
#### 1.2.1. Authentication Levels
- Trong Gitlab, có thể set và modify quyền của mọi người dựa theo vai trò của họ. Trong Github, bạn có thể quyết định nếu có ai đó lấy  quyền đọc hoặc ghi truy cập vào kho lưu trữ.
- Với Gitlab, bạn có thể cung cấp truy cập đến issue tracker mà không cần cấp quyền cho source code.
#### 1.2.2. Gitlab CI vs GitHub Actions
- 1 trong những sự khác biệt lớn giữa Gitlab và Githubn là tích hợp liên  (CI/CD: Continuous Integration/Delivery). 
- GitLab cung cấp CI của riêng mình miễn phí. Không cần sử dụng dịch vụ CI bên ngoài.
- Gitlab cung cấp AutoDevOps tự động chạy CI/CD mà không có người thiết lập nó.
- Github đã phát hành Actions vào cuối năm 2019 cho phép lập trình viên viết các tác vụ tự động hóa và tùy chỉnh quy trình phát triển. Nhưng Github không đi kèm với deployment platform và cần bổ sung thêm các ứng dụng như Heroku.
## 2. Tạo Project 
- Khi tạo một project mới sẽ có 3 quyền:
    - private: Dùng để tạo những dự án chỉ hiển thị với người được thêm vào dự án. Các quyền của người dùng được mời sẽ phụ thuộc vào phân quyền do người quản trị quyết định khi thực hiện mời.
    - internal: Dùng để tạo project giới hạn những người có tài khoản trong hệ thống Gitlab. Những người dùng đã đăng nhập sẽ được phân quyền tự động là Guest.
    - public: sẽ cho phép mọi người xem project, pull code của mình. Kể cả người xem không có tài khoản trên hệ thống. Người dùng có tài khoản trên hệ thống dù không được chấp nhận truy cập vẫn có thể tạo các merge request hoặc mở một issue.
- Giao diện khi tạo một project mới:

![](./image_gitlab/create_project.png)

### 2.1. Clone source code về máy
- Step 1: Cài đặt Git
```git --version``` : kiểm tra phiên bản  Git hiện tại 
```sudo apt install git``` : Cài đặt Git
- Step 2: Cấu hình Git
```git config --global user.name "Your Name"```
```git config — global user.email “you@example.com ``` 
- Step 3: Cloning a Gitlab repo
    - Đăng nhập vào Gitlab bằng account của bạn và đi đến repository mà bạn muốn clone.
    - Click vào clone button và chọn copy link ssh.
    - Chạy lệnh sau tại cửa sổ terminal:
    ```git clone (PASTE HERE YOUR ADDRESS)```

- Khi sảy ra lỗi như thế này thì xử lý bằng cách add ssh key
![Lỗi khi clone bằng ssh](./image_gitlab/error_gitclone.png)

[Link tham khảo tạo ssh key](https://docs.gitlab.com/ee/ssh/)
    - Từ teminal chạy dòng lệnh sau để tạo SSH key```ssh-keygen```
    Bạn sẽ được yêu cầu nhập passwork để bảo private key tránh bị người khác biết được private key thì có thể mạo danh bạn.
    - Thường key được tạo sẽ được lưu trong folder .ssh và có 2 file cần lưu ý là:
        - id_rsa : đây là PRIVATE key. Không chia sẻ key này cho bất cứ ai.
        - id_rsa.pub: đây là PUBLIC key. Có thể chia sẻ cho người khác (Sử dụng để add vào gitlab) 
    - Add SSH key của bạn vào Gitlab
        - Copy nội dung trong file id_rsa.pub (bắt đầu từ ssh-rsa đến hết file)
        - Đăng nhập vào Gitlab bằng account của bạn
        - Chọn vào avatar của bạn ở góc trên bên phải của màn hình
        - Chọn Preferences
        - Từ sidebar bên trái chọn SSH Keys
        - Trong Key box paste nội dung Public key bạn đã copy vào. 
        - Điền vào Title box và chọn thời gian sử dụng
        - Chọn add key để hoàn tất.
    - Từ teminal thực hiện clone lại repo.
## 3. Tạo Merge Request
- Gitlab bổ sung chức năng “Người duyệt” (Approvers) để giúp làm việc teamwork dễ dàng hơn, chẳng hạn như cần người review trước khi duyệt (double-check).
- Khi thêm một tính năng qua Merge Request, người duyệt có thể nhìn thấy các phần code đã chỉnh sửa một cách rõ ràng và có thể đưa ra quyết định cái gì là cần thiết hay không.
- Khi checkout branch mới nên chủ động tạo merge request ở thời điểm có commit đầu tiên (Hoặc thời điểm đã hoàn tất fix một phần nào đó)

- Cách tạo Merge Request
    - Bước 1: Truy cập vào gitlab.com , đăng nhập bằng tài khoản cá nhân. Truy cập vào branch đang làm việc có nút Merge Request  (Ở thanh công cụ bên trái) như hình sau:
    ![merge request](./image_gitlab/MR.png)
    - Bước 2: Chọn New Merge Request và điền các thông tin:
        - sourse branch: là nhánh bạn phát triển
        - Target branch: Nhánh gốc bạn merge vào
    Chọn Compare branches and continue: để tiếp tục.
    - Bước 3: Điền thêm các nội dung để  Approvers có thể nắm bắt và biết nội dung bạn muốn merge.
        - Nếu chưa hoàn thành thì ở phần Title điền thêm ```Draft:``` ở đầu nội dung.
        - Các mục quan trọng khác cần chú ý:
            - Assignee: có 2 lựa chọn, hoặc là đặt tên người phụ trách review code trước khi cho vào branch, hoặc là chính người làm branch này. Thông thường nên chọn là người làm branch này.
            - Approvers: người được lựa chọn để review code. Thường là Tech Lead hoặc Owner của một gói tính năng nào đó. Bạn có thể chọn 1 hoặc 2 (2 thì thường bao gồm cả Lead và Owner).
            - Approvals required: số người tối thiểu validate code thì mới cho phép merge thành công. Thường là 1 hoặc 2.
    
    Kiểm tra lại các commit muốn tạo merge request đã khớp chưa và ấn “Submit merge request” để khởi tạo. 
## 4. Issue
- Sử dụng Issue cho các mục đích, tùy chỉnh theo yêu cầu và công việc của bạn:
    - Thảo luận về việc triển khai một ý tưởng
    - Theo dõi nhiệm vụ và tình trạng công việc
    - Chấp nhận các đề xuất tính năng mới, câu hỏi, yêu cầu hỗ trợ hoặc báo cáo bug.
    - Xây dựng và triển khai sourse code
- Issue thường gắn với từng dự án cụ thể.
### 4.1. Tạo Issue mới
- Vào Issues > List và chọn New issue. Hoặc chọn Import CSV để import list task có sẵn từ các nguồn khác như Jira, Redmine...
- Điền nội dung cho Issue mới:

    ![Create new Issue](./image_gitlab/new_issue.png)
- Điền đủ nội dùng rồi chọn create Issue để hoàn thành.

[Link tham khảo](http://git.viettel.vn:8180/help/user/project/issues/managing_issues.md#create-a-new-issue:)
### 4.2. Di chuyển Issue
- Di chuyển 1 issue copy đến một target project, và đóng issue đó tại project nguồn. Issue gốc sẽ không bị xóa. Hệ thống sẽ ghi chú lại và chỉ ra Issue đó đến từ đầu và đến đâu và được thêm vào cả 2 issue.
- Vào Issue cần di chuyển, chọn "Move issue" ở right - sidebar và chọn project move tới. Sau đó click vào **Move**

    ![Move issue](./image_gitlab/move.png)

### 4.3. Đóng Issue
- Khi Issue đã được giải quyết, và nó không cần thiết thì có thể đóng Issue bằng button "Close Issue"
- [Link tham khảo:](http://git.viettel.vn:8180/help/user/project/issues/managing_issues.md#closing-issues)
### 4.4. Xóa Issue
- [Link tham khảo:](http://git.viettel.vn:8180/help/user/project/issues/managing_issues.md#deleting-issues)
- Người dùng quyền owner có thể chỉnh sửa Issue và chọn Deleting Issue để xóa.
### 4.5. Due dates
- Khi tạo một Issue, chọn **Due date** và chọn lịch.
### 4.6. Linked issue
- Linked issues là mối quan hệ 2 hướng giữa 2 issues bất kì và xuất hiện block bên trên mỗi mô tả của issue.
- add linked issue:
    - Link 1 issue tới 1 issue khác bằng cách chọn button add linked issue ({plus}) trên Linked issues section của 1 issue.
    - chọn mối quan hệ giữa 2 issues:
        - relates to
        - blocks (PREMIUM)
        - is blocked by (PREMIUM)
    - Nhập issue number hoặc dán full URL của issue
    - Chọn Add để kết thúc
## 5. Git CI/CD
- Với phương pháp phát triển phần mềm liên tục, bạn liên tục xây dựng, kiểm tra và triển khai các thay đổi mã lặp đi lặp lại. Quá trình lặp đi lặp lại này giúp giảm khả năng bạn phát triển mã mới dựa trên các phiên bản trước bị lỗi hoặc không thành công. Với phương pháp này, bạn cố gắng ít có sự can thiệt nào từ khi phát triển mã mới cho đến khi triển khai mã.
- Gitlab CI/CD là một công cụ được tích hợp trong Gitlab để phát triển phần mềm thông qua các phương pháp liên tuc:
    - Continuous Integration (CI)
    - Continuous Delivery (CD)
    - Continuous Deployment (CD)
- Continuous Integration (tích hợp liên tục)
    - Các ứng dụng có sourse code lưu trữ trên Git repo của Gitlab. Lập trình viên push những thay đổi code lên hằng ngày và nhiều lần mỗi ngày. Đối với mỗi lần push thay đổi lên repo, có thể tạo một tập hợp các lệnh để build hoặc test ứng dụng đang phát triển một cách tự động. Các tập lệnh này giúp giảm khả năng có lỗi trong ứng dụng.
- Continuous Delivery 
    - Là 1 bước triển khai ngoài Continuous Integration. Không chỉ app đang phát triển được build và test mỗi thời điểm code thay đổi được push lên codebase, app cũng được deployed liên tục. 
    - Tuy nhiên với Continuous delivery, bạn kích hoạt deployed một cách thủ công
    - Continuosu delivery sẽ tự động kiểm tra mã nguồn, nhưng nó yêu cầu sự can thiệp của con người để kích hoạt việc triển khai các thay đổi theo cách thủ công.
- Continuous Deployment
    - Là một bước triển khai ngoài Continuous Integration, giống với Continuous Delivery. Sự khác biệt là nó thay thế việc deploy bằng thủ công, người dùng sẽ cài đặt nó tự động deploy.
### 5.1. Gitlab CI/CD workflow
- Gitlab CI/CD phù hợp với quy trình phát triển chung.
- Lập trình viên có thể bắt đầu bằng cách bàn luận việc triển khai code trong 1 issue và làm việc cục bộ về các thay đổi đề xuất của lập trình viên. Sau đó lập trình viên có thể push commit của họ đến một nhánh tính năng  trên remote repo (trong gitlab ). Đẩy Kích hoạt CI/CD pipeline cho dự án đang làm việc. Khi đó, Gitlab CI/CD sẽ:
    - Chạy tự động scripts để:
        - Build and test application
        - Xem lại các thay đổi trong Review App, giống như xem trên localhost.
- Sau đó việc triển khai hoạt động như mong đợi:
    - Lấy code đã được review và approve
    - Merge branch đó vào branch mặc định
        - Gitlab CI/CD deploys sự thay đổi của lập trình viên một cách tự động đến môi trường sản xuất.
- Nếu có sự cố thì có thể khôi phục thay đổi:
![gitlab_workflow_example](./image_gitlab/gitlab_workflow_example_11_9.png)

[link sourse ảnh](http://git.viettel.vn:8180/help/ci/introduction/index.md#gitlab-cicd-workflow)

Workflow này show ra những bước chính trong quy trình của Gitlab. Bạn không cần bất cứ công cụ ngoài nào đề deliver phần mềm của bạn và bạn có thể  visualize tất cả các bước trong Gitlab UI

