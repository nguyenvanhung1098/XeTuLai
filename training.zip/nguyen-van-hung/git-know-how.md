# Git 
## 1. Git là gì?
### 1.1. Git
- Git là một hệ thống quản lý phiên bản phân tán (Distributed Version Control System DVCS), nó là một trong những hệ thống quản lý phiên bản phổ biến nhất hiện nay.
- Git cung cấp cho mỗi lập trình viên kho lưu trữ (repository) riêng chứa toàn bộ lịch sử thay đổi.
### 1.2. VCS (Version Control System)
- VCS (Version Control System): hệ thống kiểm soát các phiên bản phân tán mã nguồn mở. Các VCS sẽ lưu trữ tất cả các file trong toàn bộ dự án và ghi lại toàn bộ lịch sử thay đổi file. Mỗi sự thay đổi được lưu lại và thành một version.
- Lập trình viên có thể xem lại danh sách các sự thay đổi của file như xem một dòng thời gian của các phiên bản. Mỗi phiên bản bao gồm: nội dung file bị thay đổi, ngày giờ sửa đổi, người thay đổi, lý do thay đổi, tên phiên bản ,...
- Tác dụng của VCS:
    - Lưu lại lịch sử thay đổi của các Version. Giúp xem lại các sự thay đổi hoặc khôi phục (revert) lại.
    - Chia sẻ code dễ dàng (lập trình viên có thể để public hoặc để private cho một số người có quyền có thể  truy cập sử dụng code)
### 1.3. Git hoạt động như thế nào?
- Sự khác biệt giữa Git và các hệ thống VCS khác là cách Git nghĩ về data của nó. Hầu hết các hệ thống VCS (CVS, Subversion, Perforce, Bazaar,...) lưu trữ lại thông tin dưới tập hợp các file và những thay đổi trên các file theo thời gian.
![Getting Started](./image_git/VCS_storingdata.png)
Hình 1.1 Lưu trữ dữ liệu dựa trên sự thay đổi phiên bản của các file cơ sở
Sourse: https://git-scm.com/book/en/v2/Getting-Started-What-is-Git%3F
- Git không lưu trữ dữ liệu của mình theo cách này. Git coi thông tin được lưu trữ là một tập hợp các snapshot-ảnh chụp toàn bộ nội dung tất các các file tại thời điểm "commit".
- Mỗi khi "commit", Git sẽ "chụp" và tạo ra một snapshot cùng một tham chiếu tới snapshot đó. Nếu các file không thay đổi, Git sẽ không lưu trữ lại file - chỉ là một liên kết đến tệp file trước đó mà nó lưu trữ.
![Getting Started](./image_git/storing_dataSnapshot.png)
Hình 1.2 Lưu trữ dữ liệu theo Snapshot của dự án theo thời gian
Sourse: https://git-scm.com/book/en/v2/Getting-Started-What-is-Git%3F
- Đây là điểm khác biệt quan trọng giữa Git và hầu như tất cả các hệ thống VCS khác. Nó khiến Git phải xem xét lại hầu hết mọi khía cạnh của kiểm soát phiên bản mà hầu hết các hệ thống khác đã sao chép từ thế hệ trước. Điều này làm cho Git giống như một hệ thống tệp nhỏ với một số công cụ cực kỳ mạnh mẽ được xây dựng trên nó, thay vì chỉ đơn giản là một VCS.
### 1.4. Quy trình xử lý công việc (workflow) trên Git
- Các trạng thái của file: File có 3 trạng thái
    - Modified: file đã được thay đổi nhưng chưa "commit" với database
    - Staged: Đánh dấu file đã được thay đổi so với phiên bản hiện tại của nó, sẵn sàng commit snapshot
    - Committed: Dữ liệu được lưu trữ an toàn trong cơ sở dữ liệu cục bộ (tạo ra một snapshot- ảnh chụp phiên bản mới).

![Getting Started](./image_git/stage_file.png)

Hình 1.3. Working tree, Staging area và .git directory
Sourse: https://git-scm.com/book/en/v2/Getting-Started-What-is-Git%3F

## 2. Lợi ích của Git
- Lưu lại được các phiên bản khác nhau của mã nguồn dự án phần mềm.
- Khôi phục lại mã nguồn từ một phiên bản bất kỳ.
- Dễ dành so sánh giữa các phiên bản
- Phát hiện được ai đã sửa phần nào làm phát sinh lỗi
- Khôi phục lại tập tin bị mất
- Dễ dàng thử nghiệm, mở rộng tính năng của dự án mà không làm ảnh hưởng đến phiên bản chính (master branch)
- Giúp phối hợp thực hiện dự án trong nhóm một cách hiệu quả
## 3. Một số khái niệm và lệnh cơ bản trong Git
### 3.1. Git config
- Để set user name và email trong main configuration file.
- Cú pháp:
    ```
    git config -- global user.name = "user_name"
    git config -- global user.email = "user_mail"
    ```
### 3.2. git init
- Khởi tạo 1 git repository 1 project mới hoặc đã có.
- Cú pháp
    ```git init```
### 3.3. git clone
- Copy 1 git repository từ remote source về local repository
- Cú pháp: ```git clone <:clone git url:>```
### 3.4. git status
- Để check trạng thái của những file đã thay đổi trong thư mục làm việc. 
VD: Tất cả các thay đổi cuối cùng từ lần commit cuối cùng.
- Cú pháp: ```git status``` trong thư mục làm việc
### 3.5. git add
- Thêm thay đổi đến stage/index trong thư mục làm việc.
- Cú pháp: ```git add``` 
### 3.6. Git Repository
- Repository là nơi sẽ ghi lại trạng thái của thư mục và file. Trạng thái được lưu lại đang được chứa như là lịch sử thay đổi của nội dung.
- Có 2 loại Repo:
    - Remote repository: Là repository để chia sẻ giữa nhiều người và bố trí trên server chuyên dụng.
    - Local repository: Là repository bố trí trên máy của bản thân mình, dành cho một người dùng sử dụng.
### 3.7. Branch
#### 3.7.1. Giới thiệu Branch
[Sourse: Tham khảo](https://www.atlassian.com/git/tutorials/using-branches#:~:text=The%20git%20branch%20command%20lets,checkout%20and%20git%20merge%20commands)

- Trong Git, branch là một phần của công việc phát triển hằng ngày. Branch là một con trỏ trỏ tới snapshot của thay đổi của bạn. Khi muốn thêm 1 tính năng mới hoặc fix bug - bất kể thay đổi to hay nhỏ nên sinh ra một branch mới để đóng gói những thay đổi đó. Điều này làm cho những mã không ổn định khó được hợp nhất vào nhánh chính (main/master) và có cơ hội để làm sạch lịch sử trong tương lai trước khi hợp nhất nó vào nhánh chính.

![Getting Started](./image_git/Branch.png)

Hình 1.4. Minh họa branch trong Git

- Các Branch (nhánh) đại diện cho các phiên bản cụ thể của một kho lưu trữ tách ra từ project chính của bạn.

- Branch cho phép bạn theo dõi các thay đổi thử nghiệm bạn thực hiện đối với kho lưu trữ và có thể hoàn nguyên về các phiên bản cũ hơn.
#### 3.7.1. Một số câu lệnh với Branch
- ```git branch```:
Hiển thị những branch trong repo local
- ```git branch <branch>```:
Tạo một branch mới <branch> nhưng không checkout sang branch mới.
    ```git checkout -b <branch>```
    Tạo và chuyển sang một nhánh mới.
- ```git branch -d <branch>```:
Xóa một nhánh trong git (Nhánh chỉ định sẽ không được xóa nếu còn có thay đổi mà chưa được merge)
- ```git branch -D <branch>```:
Buộc xóa nhóm đã chỉ định.
- ```git branch -m <branch>```:
Đổi tên nhánh hiện tại thành <branch>
- ```git branch -a```
Hiển thị tất cả các remote branches.
- Tạo một branch: 1 branch chỉ là một con trỏ trỏ tới commits. Khi tạo mới branch, tất cả những việc Git làm là tạo 1 con trỏ mới, nó sẽ không thay đổi repository theo bất kì cách nào. Nếu bắt đầu với một repository thì nó sẽ như hình sau:

    ![Getting Started](./image_git/mainrepo.png)

Khi chạy lệnh: ``` git branch crazy-experiment``` thì lịch sử  repository không hề thay đổi. Chỉ có 1 con trỏ mới trỏ tới commit hiện tại như hình sau:

![Getting Started](./image_git/main_repo.png)

- Tạo remote branch
```
$ git remote add new-remote-repo https://bitbucket.com/user/repo.git
# Add remote repo to local repo config
$ git push <new-remote-repo> crazy-experiment~
# pushes the crazy-experiment branch to new-remote-repo
```
- Chuyển giữa các branch:
    ```git checkout <branch>```

### 3.8. Commit
- Một commit đại diện cho một thời điểm cụ thể trong lịch sử dự án (snapshot). Sử dụng lệnh commit kết hợp với lệnh git add để cho git biết những thay đổi bạn muốn lưu vào local repository.
- Cú pháp: [Link tham khảo](https://git-scm.com/docs/git-commit)
    ```
    git commit [-a | --interactive | --patch] [-s] [-v] [-u<mode>] [--amend]
        [--dry-run] [(-c | -C | --squash) <commit> | --fixup [(amend|reword):]<commit>)]
        [-F <file> | -m <msg>] [--reset-author] [--allow-empty]
        [--allow-empty-message] [--no-verify] [-e] [--author=<author>]
        [--date=<date>] [--cleanup=<mode>] [--[no-]status]
        [-i | -o] [--pathspec-from-file=<file> [--pathspec-file-nul]]
        [(--trailer <token>[(=|:)<value>])…​] [-S[<keyid>]]
        [--] [<pathspec>…​]
    ```
### 3.9. fetch
[Link tham khảo](https://git-scm.com/book/en/v2/Git-Branching-Remote-Branches)
-  Tải dữ liệu từ Remote Repo (Các dữ liệu như các commit, các file, refs),
-  Khi chạy câu lệnh ```git fetch $remote_origin```: Git sẽ tải về dữ liệu của tất cả các branch của repository trên remote server nằm tại địa chỉ quy định bởi $remote_origin và cập nhật dữ liệu này với dữ liệu của branch phía dưới máy local.
- Tuy nhiên git fetch không cập nhật dữ liệu của working copy. Để biết sự khác biệt  dữ liệu tại working copy với trên remote server ta thực thực hiện checkout sang một nhánh rồi sử dụng lệnh: git status để xem khác biệt.
- Git tải về (fetch) dữ liệu của toàn bộ các branch trên URL quy định bởi $remote_origin nhưng không thực hiện việc merge các thay đổi này vào local.
- Tải về thông tin của tất cả các nhánh của remote có tên origin:
    ```git fetch origin``` hoặc
    ```git fetch --all```
- Tải thông tin của một nhánh, ví dụ master của remote origin:
    ```git fetch origin master```
- Xem log của một nhánh local và log của nhánh remote:
    ```git log --oneline origin/master```
- Sau khi kiểm tra sự khác biệt của nhánh giữa remote và local, có thể thay đổi cập nhật vào local repo dữ liệu tải về bằng lệnh git pull hoặc git merge. ví dụ gộp thay đổi của remote/master và master bằng merge:
    ```git merge origin/master```
### 3.10. pull
[Link tham khảo](https://git-scm.com/book/en/v2/Git-Branching-Remote-Branches)
- Khi chạy câu lệnh ```git pull $remote_origin $branch_name```, Git sẽ áp thực hiện việc fetch dữ liệu của Git repository tại nhánh ```$branch_name``` từ server nằm tại địa chỉ quy định bởi ```$remote_origin``` và áp dụng (merge) các thay đổi này vào thư mục và tập tin ở working copy.
- Câu lệnh git pull sẽ có thể gây ra xung đột (conflict) trong khi merge. Khi đó phải giải quyết các xung đột mới có thể pull được.
### 3.11. push
- Để chia sẻ lịch sử thay đổi của local repository mà bản thân đang có bằng remote repository, cần phải upload lịch sử thay đổi trong local repository.
- Khi thực hiện Push, lịch sử thay đổi của bản thân sẽ được upload lên remote repository và lịch sử thay đổi của remote repository sẽ có trạng thái giống với local repository.
### 3.12. merge
- Git Merge là một lệnh hợp nhất các nhánh trong Git. Git Merge sẽ lấy hai nhánh và tìm thấy một commit cơ sở chung giữa chúng. Khi Git tìm thấy một commit cơ sở chung, nó sẽ tạo một cam kết hợp nhất (merge commit) mới và hợp nhất các thay đổi theo trình tự của mỗi cam kết hợp nhất.
- VD git merge:
    ```
    $ git checkout master
    Switched to branch 'master'
    $ git merge iss53
    Merge made by the 'recursive' strategy.
    index.html |    1 +
    1 file changed, 1 insertion(+)
    ```
    ![Getting Started](./image_git/merge1.png)
    3 ảnh chụp Snapshot chuẩn bị merge

    ![Getting Started](./image_git/merge2.png)
    Sau khi merge
[Link tham khảo](https://git-scm.com/book/en/v2/Git-Branching-Basic-Branching-and-Merging)

### 3.13. rebase
- Git Rebase được sử dụng để nhập một branch đã gần hoàn thiện vào branch gốc.
- Lí do chính sử dụng chính của Git Rebase đó là để lưu giữ lịch sử làm việc của dự án một cách tuyến tính.

    ![Getting Started](./image_git/mergevsrebase.png)
    
    Sự khác biệt giữa merge và rebase
### 3.14. git cherry-pick
- Khi muốn lấy 1 hay n commits từ 1 brach bỏ vào master, hoặc commit 1 lần và lên 2 branch, thì git merge hay rebase thì đôi khi quá dư thừa.
git cherry-pick có thể lấy thay đổi của 1 commit hay n commit trên 1 nhánh nào đó áp dụng vào nhánh hiện tại.
- Cú pháp:
    ```
    git cherry-pick [--edit] [-n] [-m parent-number] [-s] [-x] [--ff]
            [-S[<keyid>]] <commit>…
    git cherry-pick --continue
    git cherry-pick --quit
    git cherry-pick --abort

    ```
[Link tham khảo](https://viblo.asia/p/git-nang-cao-git-cherry-pick-RQqKLQ9pZ7z)
## 4. Git hook
[Link tham khảo](https://www.atlassian.com/git/tutorials/git-hooks#conceptual-overview)
### 4.1. Tổng quan
- Tất cả các hook của Git đều là các script thông thường mà Git thực thi khi các sự kiện nhất định xảy ra trong kho lưu trữ. Điều này làm cho chúng rất dễ cài đặt và cấu hình.
- Các hook có thể nằm trong kho lưu trữ cục bộ hoặc phía máy chủ và chúng chỉ được thực thi theo các hành động trong kho lưu trữ đó. 
### 4.2. Cài đặt hooks
- hooks được đặt trong thư mục .git/hooks của mọi Git repository.
- Git sẽ tự động cài các file trong thư mục .git/hooks khi khởi tạo Git bằng lệnh ```git init```.

![Getting Started](./image_git/githook.png)
Các file trong thư mục hooks có định dạng .sample
Các file này sẽ chạy khi có các sự kiện nhất định xảy ra như trước khi commit, push, pull ...

