# Network 
(Nguồn hình ảnh trong doc lấy từ slide Mạng máy tính - Thầy Bùi Trọng Tùng - Đại học Bách khoa Hà Nội)
[Link slide](https://users.soict.hust.edu.vn/tungbt/it3080/)
## 1. Mô hình OSI
![Getting Started](./image/osi.png)
- Tầng ứng dụng (Application): cung cấp các ứng dụng trên mạng (web, email, truyền file...)
- Tầng Trình diễn (Presentation): biểu diễn dữ liệu của các ứng dụng, eg: mã hóa, nén, chuyển đổi...
- Tầng Phiên (Session): quản lý phiên bản làm việc, đồng bộ hóa phiên, khôi phục quá trình trao đổi dữ liệu
- Tầng Giao vận (Transport): Xử lý việc truyền nhận dữ liệu cho các ứng dụng chạy trên nút mạng đầu cuối.
- Tầng Mạng (Network): Chọng đường (định tuyến), chuyển tiếp gói tin từ nguồn đến đích.
- Tầng liên kết dữ liệu (Data link): Truyền dữ liệu trên các liên kết vật lý giữa các nút mạng kế tiếp nhau.
- Tầng Vật lý (Physical): Chuyển dữ liệu (bit) thành tín hiệu và truyền.
#### Đặc điểm mô hình OSI:
- Mô hình tham chiếu chức năng: Các mô hình khác phải tham chiếu từ mô hình OSI.
    - Cung cấp đầy đủ các chức năng mô hình OSI đã chỉ ra.
    - Đảm bảo thứ tự các tầng chức năng.
- Có ý nghĩa lớn về mặt cơ sở lý thuyết. 
## 2. Mô hình TCP/IP
- Trong mô hình TCP/IP (Internet), chức năng 3 tầng trên được phân định cho một tầng duy nhất.
![Getting Started](./image/TCP_IP.png)
- Mô hình TCP/IP (Mô hình internet) sử dụng ở hầu hết các hệ thống mạng.
- Triển khai kiến trúc phân tầng:

![Getting Started](./image/TrienKhaiKienTrucPhanTangTCPIP.png)

    -  Nút mạng đầu cuối (end-system): PC, server, smartphone....
    -  Nút mạng trung gian: các thiết bị mạng chuyển tiếp dữ liệu

![Getting Started](./image/NutMangDauCuoi.png)
![Getting Started](./image/NutMangTrungGian.png)
- Chồng giao thức TCP/IP:

![Getting Started](./image/ChongGiaoThucTCPIP.png)
- Định danh trên TCP/IP:

![Getting Started](./image/DinhDanhTrenTCPIP.png)

    - Tên miền (Domain name)
    - Port Number: Định danh sử dụng trên tầng giao vận : 16 bit, một chỉ số dùng kèm theo địa chỉ IP để định danh cho ứng dụng trên mạng
    eg: HTTP cổng 80, FTP cổng 20,21 ...
    - Địa chỉ IP: Định danh dùng trên tầng mạng
    - Physical address / MAC address: 48 bit => sử dụng để định danh máy tính trong mạng cục bộ (do nhà sản xuất cấu hình)
## 3. Encapsulation và Decapsulation của gói tin khi đi qua các layer
## 4. DHCP, ARP, DNS, routing, switching
### 4.1. DHCP (Dynamic Host Configuration Protocol)
- Dynamic Host Configuration Protocol
- Dịch vụ tầng ứng dụng cung cấp cấu hình địa chỉ IP cho các nút mạng:
    - Địa chỉ IP
    - Mặt nạ mạng
    - Địa chỉ bộ định tuyến mặc định (default router, default gateway)
    - Có thể địa chỉ máy chủ DNS phân giải mã miền
- Hoạt động theo mô hình client/server: client sử dụng các thông số địa chỉ IP do server cấp phát
- Các thông điệp DHCP.

![Getting Started](./image/CacThongDiepDHCP.png)

- Hoạt động cấp phát cấu hình mới:

![Getting Started](./image/CapPhatCauHinhMoi.png)

- Gia hạn sử dụng

![Getting Started](./image/GiaHanThoiGianSuDung.png)

- DHCP delay

![Getting Started](./image/DHCP_DELAY.png)

### 4.2. ARP (Address Resolution Protoco)
- Tìm địa chỉ MAC (định danh tầng liên kết dữ liệu) của một nút mạng khi đã biết địa chỉ IP.
![Getting Started](./image/DHCP1.png)
- Hoạt động của ARP:
![Getting Started](./image/HD_ARP.png)
### 4.3. DNS (Domain Name System)
**Hệ thống tên miền**
- Không gian thông tin tên miền
- Gồm các máy chủ quản lý thông tin tên miền và cung cấp dịch vụ DNS
### 4.4. Routing (Định tuyến)
- Tìm tuyến đường (qua các nút trung gian) để gửi dữ liệu từ nguồn tới đích.
- sử dụng thuật toán định tuyến tính toán bảng chuyển tiếp (Forwarding Table), chuyển tiếp theo địa chỉ IP đích.
### 4.5. Switching (Chuyển mạch)
-  Sử dụng cơ chế tự học tính toán bảng MAC Table, chuyển tiếp theo địa chỉ MAC đích
### 4.6. Routing tables
![Getting Started](./image/Router_table.png)
### 4.7. IP Table
- Được cài đặt trong thư mục /usr/sbin/iptables
- Dùng lệnh ```man iptables``` để xem chỉ dẫn.
- Dùng để thiết lập các luật 
### 4.8. NAT (Network Address Translation)
- Dữ liệu chuyển tiếp từ mạng LAN(sử dụng địa chỉ cục bộ) sang mạng Internet(sử dụng địa chỉ công cộng) và ngược lại cần được chuyển đổi địa chỉ.
- Trên thực tế, có thể sử dụng NAT để chuyển đổi địa chỉ IP từ mạng LAN này sang mạng LAN khác.
- Lợi ích:
    - Tiết kiệm địa chỉ IP công cộng
    - Che giấu mạng riêng
    - Giảm chi phí cấu hình thay đổi ISP
- Các chế độ hoạt động của NAT
    - Static NAT: mỗi địa chỉ IP cục bộ được chuyển đổi sang một địa chỉ IP công cộng
    - Dynamic NAT: Một dải địa chỉ IP được chuyển đổi sang một/một dải địa chỉ IP công cộng
    - PAT : Port Address Translation: NAT with overloading sử dụng thêm số hiệu cổng ứng dụng trong quá trình chuyển đổi

- Hoạt động của Dynamic NAT.

![Getting Started](./image/Dynamic_NAT.png)

- Hoạt động của PAT

![Getting Started](./image/PAT.png)

### 4.9. port-forwarding
- Cho phép máy tính bên ngoài kết nối đến máy tính bên trong mạng nội bộ. Thông thường, router/server mở sẵn một số port, chẳng hạn port 21 cho dịch vụ chia sẻ tập tin qua FTP, port 80 cho các máy chủ dịch vụ web (web server)...

## 5. Network trong Linux
### 5.1. Network namespace
- Network namespace giúp ta có các mạng riêng biệt trên một host.
- Mỗi namespace sẽ có những giao diện (interface) và bảng định tuyến (routing table).
- Linux bridge:
#### 5.1.1. Làm việc với Namespace
- Khi khởi động Linux hệ thống sẽ có một namespace. Các tiến trình khi được tạo mới sẽ kế thừa namespace này.
- Để làm việc với namespace sử dụng lệnh: ```ip netns```

- [ ] Liệt kê danh sách các namespace trong hệ thống:
``` 
ip netns list
```
- [ ] Tạo mới một namespace:
```
ip netns add "name of namespace"
``` 
- Mỗi namespace được tạo mới có một file tương ứng cùng tên với tên của namespace tạo ra trong thư mục /var/run/netns
- [ ] Commands trong namespace
- Thực thi một lệnh trong namespace:
```
sudo ip netns exce "name_ofNamespace" "command"
```
#### 5.1.2. Ping giữa 2 Namespace
Kịch bản:
- Mô phỏng 2 node (Mỗi namespace đại diện 1 node)
- Kết nối 2 namespace tới một switch ảo (virtual switch)
- ping từ namespace này đến namespace khác
- [ ] Tạo 2 namespace là : namespace1 và namespace2
- [ ] Tạo virtual switch
- cài đặt Open vSwitch và khởi động service của nó
```
sudo apt-get install openvswitch-switch
sudo /etc/init.d/openvswitch-switch start
```
- Tạo 1 virtual switch trong namespace mặc định của hệ thống có tên là my_switch:
```
sudo ovs-vsctl add-br my_switch
```
- Kiểm tra xem my_switch đã được tạo thành công chưa:
```
sudo ovs-vsctl show
```
- Để xóa 1 virtual switch: 
```
sudo ovs-vsctl --if-exists del-br my_switch
```
- Sử dụng veth (virtual ethernet) để kết nối namespace đến my_switch
    - add veth:
    ```
    sudo ip link add type veth
    ```
    - kiểm tra veth đã được add chưa : 
    ```
    ip address
    ```
    - Xóa 1 veth:  ```sudo ip link del 'name_veth'```
    - Tạo veth kết nối 1 namespace1 với my_switch
    ```
    sudo ip link add namespace1-netns type veth peer name namespace1-ovs
    ```
    namespace1-netns sẽ được thiết lập trong  _namespace1_ và namespace1-ovs sẽ kết nối với vitural switch.
    - Đặt namespace1-netns vào trong namespace _namespace1_:
    ```
    sudo ip link set namespace1-netns netns namespace1
    ```
    - Kết nối veth còn lại namespace1-ovs với my_switch:
    ```
    sudo ovs-csctl add-port my_switch namespace1-ovs
    sudo ovs-vsctl show
    ```
    
    Làm các bước tương tự với namespace2:
    ```
    sudo ip link add namespace2-netns type veth peer name namespace2-ovs
    sudo ip link set namespace2-netns netns namespace2
    sudo ovs-csctl add-port my_switch namespace2-ovs
    ```
    - Bringing up devides
    Trong namespace mặc định của hệ thống:
    ```
    sudo ip link set namespace1-ovs up
    sudo ip link set namespace2-ovs up
    ```
     Trong namespace  namespace1 và namespace2
     ```
     sudo ip netns exec namespace1 ip link set dev lo up
     sudo ip netns exec namespace1 ip link set dev namespace1-netns up
     sudo ip netns exec namespace2 ip link set dev lo up
     sudo ip netns exec namespace2 ip link set dev namespace2-netns up
    ```
- Gán địa chỉ IP
    Gán địa chỉ IP cho các device namespace1-netns và namespace2-netns trong các namespace1 và namespace2.
    ```
    sudo ip netns exec namespace1 ip addr add 10.0.0.1/24 dev namespace1-netns
    sudo ip netns exec namespace2 ip addr add 10.0.0.2/24 dev namespace2-netns
    ```
    
    ```
    Kiểm tra:
    sudo ip netns exec namespace1 ip a
    ```
- Ping:
    ```
    sudo ip netns exec namespace1 ping 10.0.0.2
    ```
    ###### Kết quả:
    ![Getting Started](./image/result_lab.png)

     

