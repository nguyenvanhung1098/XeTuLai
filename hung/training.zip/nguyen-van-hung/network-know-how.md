# Network 
(Nguồn hình ảnh trong doc lấy từ slide Mạng máy tính - Thầy Bùi Trọng Tùng - Đại học Bách khoa Hà Nội)
[Link slide](https://users.soict.hust.edu.vn/tungbt/it3080/)
## 1. Mô hình OSI
![Getting Started](./image/osi.png)
- Tầng ứng dụng (Application): cung cấp các ứng dụng trên mạng (web, email, truyền file...)
- Tầng Trình diễn (Presentation): biểu diễn dữ liệu của các ứng dụng, eg: mã hóa, nén, chuyển đổi...
- Tầng Phiên (Session): quản lý phiên bản làm việc, đồng bộ hóa phiên, khôi phục quá trình trao đổi dữ liệu
- Tầng Giao vận (Transport): Xử lý việc truyền nhận dữ liệu cho các ứng dụng chạy trên nút mạng đầu cuối.
- Tầng Mạng (Network): Chọng đường (định tuyến), chuyển tiếp gói tin từ nguồn đến đích.
- Tầng liên kết dữ liệu (Data link): Truyền dữ liệu trên các liên kết vật lý giữa các nút mạng kế tiếp nhau.
- Tầng Vật lý (Physical): Chuyển dữ liệu (bit) thành tín hiệu và truyền.
#### Đặc điểm mô hình OSI:
- Mô hình tham chiếu chức năng: Các mô hình khác phải tham chiếu từ mô hình OSI.
    - Cung cấp đầy đủ các chức năng mô hình OSI đã chỉ ra.
    - Đảm bảo thứ tự các tầng chức năng.
- Có ý nghĩa lớn về mặt cơ sở lý thuyết. 
## 2. Mô hình TCP/IP
- Trong mô hình TCP/IP (Internet), chức năng 3 tầng trên được phân định cho một tầng duy nhất.
![Getting Started](./image/TCP_IP.png)
- Mô hình TCP/IP (Mô hình internet) sử dụng ở hầu hết các hệ thống mạng.
- Triển khai kiến trúc phân tầng:

![Getting Started](./image/TrienKhaiKienTrucPhanTangTCPIP.png)

    -  Nút mạng đầu cuối (end-system): PC, server, smartphone....
    -  Nút mạng trung gian: các thiết bị mạng chuyển tiếp dữ liệu

![Getting Started](./image/NutMangDauCuoi.png)
![Getting Started](./image/NutMangTrungGian.png)
- Chồng giao thức TCP/IP:

![Getting Started](./image/ChongGiaoThucTCPIP.png)
- Định danh trên TCP/IP:

![Getting Started](./image/DinhDanhTrenTCPIP.png)

    - Tên miền (Domain name)
    - Port Number: Định danh sử dụng trên tầng giao vận : 16 bit, một chỉ số dùng kèm theo địa chỉ IP để định danh cho ứng dụng trên mạng
    eg: HTTP cổng 80, FTP cổng 20,21 ...
    - Địa chỉ IP: Định danh dùng trên tầng mạng
    - Physical address / MAC address: 48 bit => sử dụng để định danh máy tính trong mạng cục bộ (do nhà sản xuất cấu hình)
## 3. Encapsulation và Decapsulation của gói tin khi đi qua các layer
## 4. DHCP, ARP, DNS, routing, switching
### 4.1. DHCP (Dynamic Host Configuration Protocol)
- Dynamic Host Configuration Protocol
- Dịch vụ tầng ứng dụng cung cấp cấu hình địa chỉ IP cho các nút mạng:
    - Địa chỉ IP
    - Mặt nạ mạng
    - Địa chỉ bộ định tuyến mặc định (default router, default gateway)
    - Có thể địa chỉ máy chủ DNS phân giải mã miền
- Hoạt động theo mô hình client/server: client sử dụng các thông số địa chỉ IP do server cấp phát
- Các thông điệp DHCP.

![Getting Started](./image/CacThongDiepDHCP.png)

- Hoạt động cấp phát cấu hình mới:

![Getting Started](./image/CapPhatCauHinhMoi.png)

- Gia hạn sử dụng

![Getting Started](./image/GiaHanThoiGianSuDung.png)

- DHCP delay

![Getting Started](./image/DHCP_DELAY.png)

### 4.2. ARP (Address Resolution Protoco)
- Tìm địa chỉ MAC (định danh tầng liên kết dữ liệu) của một nút mạng khi đã biết địa chỉ IP.
    - Truyền tin trên tầng mạng dùng địa chỉ IP
    - Truyền tin trên tầng liên kết dữ liệu dùng địa chỉ MAC
    - Khi gửi: dữ liệu chuyển từ tầng mạng xuống tầng liên kết dữ liệu.
        - Dữ liệu gửi trong mạng LAN: máy nguồn cần phải biết địa chỉ MAC của máy đích
        - Dữ liệu gửi ra ngoài mạng LAN: Máy nguồn phải biết địa chỉ MAC của bộ định tuyến.
- Hoạt động của ARP:
    - Mỗi nút trọng mạng LAN sử dụng bảng ARP Table:
        - Ánh xạ <Địa chỉ IP, Địa chỉ MAC,TTL>
        - TTL: thời gian dữ liệu ánh xạ trong bảng
        - Sử dụng lệnh ```arp``` hoặc ```arp -n``` để liệt kê nội dung hiện tại của bộ đêm ARP.
            ![image](./image/arp.png)
            
            - Cột Address: địa chỉ IP
            - HWaddress: địa chỉ MAC

    - Khi cần biết địa chỉ MAC tương ứng với địa chỉ IP không có trong ARP table, nút mạng gửi quảng bá gói tin ARP request lên trên mạng để hỏi. Nút mạng mang địa chỉ IP được hỏi sẽ gửi ARP Repy trả lời. Nếu tìm thấy thì sẽ cập nhật lại bảng ARP.

        ![image](./image/ping_arp.png)

    Sau khi ping đến một địa chỉ IP trong mạng LAN mà chưa thông tin trong bảng ARP thì ARP đã được cập nhật thêm thông tin của IP đó. 
    - ARP chỉ hoạt động trong mạng nội bộ không thể tìm địa chỉ MAC của IP khác bên ngoài mạng.

        ![image](./image/ping_youtube.png)
    
    khi ping đến 1 địa chỉ IP ngoài mạng (cụ thể là youtube.com (142.250.66.142)) thì không thể tìm được địa chỉ MAC.
        
    - Sử dụng lệnh ```man arp``` để xem hướng dẫn sử dụng các lệnh liên quan đến ARP
    - Để xóa một entry trong bảng ARP sử dụng lệnh: ```arp -d address```
        
        ![image](./image/delete_arp.png)

### 4.3. DNS (Domain Name System)
- Tên miền: Định danh trên tầng ứng dụng cho các nút mạng
- DNS (Domain Name System): Hệ thống tên miền
    - Không gian thông tin tên miền
    - Gồm các máy chủ quản lý thông tin tên miền và cung cấp dịch vụ DNS
- Máy tính và các thiết bị mạng không sử dụng tên miền mà sử dụng địa chỉ IP khi trao đổi dữ liệu. Tuy nhiên, người dùng lại sử dụng tên miền để truy cập dịch vụ thay vì sử dụng địa chỉ IP khó nhớ. Nền cần phải chuyển từ tên miền sang địa chỉ IP.
- Ví dụ chuyển đổi IP:

    ![image](./image/vd.png)

- Quy tắc đặt tên miền:
    - Độ dài tối đa: 255 ký tự
    - Độ dài tối đa của label: 63 ký tự
    - Label phải bắt đầu bằng chữ số hoặc chữ, chỉ chứa số, chữ, "-","."
        - Phân cấp tên miền:gốc, cấp 1, cấp 2
- Phân giải tên miền
    - Tự phân giải:
        - File HOST: C:\WINDOWS\system32\drviers\etc\
        - Cache
    - Dịch vụ phân giải tên miền DNS: client/server
        - UDP, port 53
        - Phân giải đệ quy
        - Phân giải tương tác
- Thông điệp DNS:
    - DNS Query và DNS Reply: Chung khuôn dạng
    - Question: tên miền cần truy vấn
        - Số lượng #Question
    - ANSWER: Thông tin tên miền tìm kiếm được
        - Số lượng #Answer RRs
    - AUTHORITY: Địa chỉ server trả lời truy vấn
    - ADDITIONAL: Thông tin phân giải tên miền cho các địa chỉ khác.
    
    ![image](./image/DNS.png)

- Phân giải tương tác:
    - Cơ chế mặc định trên máy chủ DNS:
    
    ![image](./image/PhanGiaiTuongTac.png)

- Phân giải đệ quy:
    - Tùy chọn mở rộng
    
    ![image](./image/PhanGiaiDeQuy.png)

- Ví dụ : Thực hiện lệnh ```dig youtube.com``` là lệnh để truy vấn các máy chủ hệ thống tên miền (DNS). Trường hợp này là truy vấn tên miền youtube.com. Hình sau minh họa kết quả trả về:


    ![image](./image/dig_vd.png)
 

### 4.4. Routing (Định tuyến)
- Tìm tuyến đường (qua các nút trung gian) để gửi dữ liệu từ nguồn tới đích.
- Sử dụng thuật toán định tuyến tính toán bảng chuyển tiếp (Forwarding Table), chuyển tiếp theo địa chỉ IP đích.
- Có thể sử dụng 1 những lệnh sau để xem bảng định tuyến:
    - route
    - netstat
    - ip

- Kiểm tra bảng định tuyến bằng lệnh route
    - ```route```

    ![image](./image/route.png)

    Lệnh này sẽ hiện thị danh sách các tuyến đường được cấu hình.
    hoặc ```route -n```

### 4.5. Switching (Chuyển mạch)
-  Sử dụng cơ chế tự học tính toán bảng MAC Table, chuyển tiếp theo địa chỉ MAC đích
### 4.6. Routing tables
![Getting Started](./image/Router_table.png)
    - Để xem Routing tables sử dụng lệnh route : 
    ![image](./image/route.png)

### 4.7. IP Table
- Được cài đặt trong thư mục /usr/sbin/iptables
- Dùng lệnh ```man iptables``` để xem chỉ dẫn.
- Dùng để thiết lập các luật 
- IP table là một ứng dụng tường lửa dựa trên lọc gói rất mạnh, miễn phí và có sẵn trên linux.
- Iptables/Netfilter gồm 2 phần là Netfilter ở trong kernel Linux và Iptables nằm ngoài kernel.
    - Iptables chịu trách nhiệm giao tiếp với người dùng và sau đó đẩy các luật của người dùng vào cho Netfiler xử lí.
    - Netfilter tiến hành lọc các gói dữ liệu ở mức IP. Netfilter làm việc trực tiếp trong kernel, nhanh và không làm giảm tốc độ của hệ thống.
#### 4.7.1. Cơ chế - Thành phần của IP Table
- Gồm 3 thành phần cơ bản:
    - table
    - chain
    - target
- Table: IP Table sử dụng table để định nghĩa các rules cụ thể cho các gói tin. Các phiên bản linux hiện nay có 4 loại table khác nhau:
    - Filter table: Quyết định gói tin có được chuyển đến địa chỉ đích hay không
    - Mangle table: sửa head của gói tin.
    - Table Nat: Cho phép route các gói tin đến các host khác nhau trong mạng NAT table cách thay đổi IP nguồn và IP đích của gói tin. Table này cho phép kết nối đến các dịch vụ không được truy cập trực tiếp được do đang trong mạng NAT.
    - Table raw: 1 gói tin có thể thuộc một kết nối mới hoặc cũng có thể là của 1 kết nối đã tồn tại. Table raw cho phép làm việc với gói tin trước khi kernel kiểm tra trạng thái gói tin.
- Chains: Mỗi table được tạo với một số chains nhất định. Chains cho phép lọc gói tin tại các điểm khác nhau. Iptable có thể thiết lập với các chains sau:
    - Chain PREROUTING: Các rule thuộc chain này sẽ được áp dụng ngay khi gói tin vừa vào đến Network interface. Chain này chỉ có ở table NAT, raw và mangle.
    - Chain INPUT: Các rule thuộc chain này áp dụng cho các gói tin ngay trước khi các gói tin được vào hệ thống. Chain này có trong 2 table mangle và filter.
    - Chain OUTPUT: Các rule thuộc chain này áp dụng cho các gói tin ngay khi gói tin đi ra từ hệ thống. Chain này có trong 3 table là raw, mangle và filter.
    - Chain FORWARD: Các rule thuộc chain này áp dụng cho các gói tin chuyển tiếp qua hệ thống. Chain này chỉ có trong 2 table mangle và table.
    - Chain POSTROUTING: áp dụng cho các gói tin đi network interface. Chain này có trong 2 table mangle và NAT.
https://bizflycloud.vn/tin-tuc/tim-hieu-ve-iptables-phan-1-660.htm
### 4.8. NAT (Network Address Translation)
- Dữ liệu chuyển tiếp từ mạng LAN(sử dụng địa chỉ cục bộ) sang mạng Internet(sử dụng địa chỉ công cộng) và ngược lại cần được chuyển đổi địa chỉ.
- Trên thực tế, có thể sử dụng NAT để chuyển đổi địa chỉ IP từ mạng LAN này sang mạng LAN khác.
- Lợi ích:
    - Tiết kiệm địa chỉ IP công cộng
    - Che giấu mạng riêng
    - Giảm chi phí cấu hình thay đổi ISP
- Các chế độ hoạt động của NAT
    - Static NAT: mỗi địa chỉ IP cục bộ được chuyển đổi sang một địa chỉ IP công cộng
    - Dynamic NAT: Một dải địa chỉ IP được chuyển đổi sang một/một dải địa chỉ IP công cộng
    - PAT : Port Address Translation: NAT with overloading sử dụng thêm số hiệu cổng ứng dụng trong quá trình chuyển đổi

- Hoạt động của Dynamic NAT.

![Getting Started](./image/Dynamic_NAT.png)

- Hoạt động của PAT

![Getting Started](./image/PAT.png)

### 4.9. port-forwarding
- Cho phép máy tính bên ngoài kết nối đến máy tính bên trong mạng nội bộ. Thông thường, router/server mở sẵn một số port, chẳng hạn port 21 cho dịch vụ chia sẻ tập tin qua FTP, port 80 cho các máy chủ dịch vụ web (web server)...

## 5. Network trong Linux
### 5.1. Network namespace
- Network namespace giúp ta có các mạng riêng biệt trên một host.
- Mỗi namespace sẽ có những giao diện (interface) và bảng định tuyến (routing table).
- Linux bridge:
#### 5.1.1. Làm việc với Namespace
- Khi khởi động Linux hệ thống sẽ có một namespace. Các tiến trình khi được tạo mới sẽ kế thừa namespace này.
- Để làm việc với namespace sử dụng lệnh: ```ip netns```

- [ ] Liệt kê danh sách các namespace trong hệ thống:
``` 
ip netns list
```
- [ ] Tạo mới một namespace:
```
ip netns add "name of namespace"
``` 
- Mỗi namespace được tạo mới có một file tương ứng cùng tên với tên của namespace tạo ra trong thư mục /var/run/netns
- [ ] Commands trong namespace
- Thực thi một lệnh trong namespace:
```
sudo ip netns exce "name_ofNamespace" "command"
```
#### 5.1.2. Ping giữa 2 Namespace
Kịch bản:
- Mô phỏng 2 node (Mỗi namespace đại diện 1 node)
- Kết nối 2 namespace tới một switch ảo (virtual switch)
- ping từ namespace này đến namespace khác
- [ ] Tạo 2 namespace là : namespace1 và namespace2
- [ ] Tạo virtual switch
- cài đặt Open vSwitch và khởi động service của nó
```
sudo apt-get install openvswitch-switch
sudo /etc/init.d/openvswitch-switch start
```
- Tạo 1 virtual switch trong namespace mặc định của hệ thống có tên là my_switch:
```
sudo ovs-vsctl add-br my_switch
```
- Kiểm tra xem my_switch đã được tạo thành công chưa:
```
sudo ovs-vsctl show
```
- Để xóa 1 virtual switch: 
```
sudo ovs-vsctl --if-exists del-br my_switch
```
- Sử dụng veth (virtual ethernet) để kết nối namespace đến my_switch
    - add veth:
    ```
    sudo ip link add type veth
    ```
    - kiểm tra veth đã được add chưa : 
    ```
    ip address
    ```
    - Xóa 1 veth:  ```sudo ip link del 'name_veth'```
    - Tạo veth kết nối 1 namespace1 với my_switch
    ```
    sudo ip link add namespace1-netns type veth peer name namespace1-ovs
    ```
    namespace1-netns sẽ được thiết lập trong  _namespace1_ và namespace1-ovs sẽ kết nối với vitural switch.
    - Đặt namespace1-netns vào trong namespace _namespace1_:
    ```
    sudo ip link set namespace1-netns netns namespace1
    ```
    - Kết nối veth còn lại namespace1-ovs với my_switch:
    ```
    sudo ovs-csctl add-port my_switch namespace1-ovs
    sudo ovs-vsctl show
    ```
    
    Làm các bước tương tự với namespace2:
    ```
    sudo ip link add namespace2-netns type veth peer name namespace2-ovs
    sudo ip link set namespace2-netns netns namespace2
    sudo ovs-csctl add-port my_switch namespace2-ovs
    ```
    - Bringing up devides
    Trong namespace mặc định của hệ thống:
    ```
    sudo ip link set namespace1-ovs up
    sudo ip link set namespace2-ovs up
    ```
     Trong namespace  namespace1 và namespace2
     ```
     sudo ip netns exec namespace1 ip link set dev lo up
     sudo ip netns exec namespace1 ip link set dev namespace1-netns up
     sudo ip netns exec namespace2 ip link set dev lo up
     sudo ip netns exec namespace2 ip link set dev namespace2-netns up
    ```
- Gán địa chỉ IP
    Gán địa chỉ IP cho các device namespace1-netns và namespace2-netns trong các namespace1 và namespace2.
    ```
    sudo ip netns exec namespace1 ip addr add 10.0.0.1/24 dev namespace1-netns
    sudo ip netns exec namespace2 ip addr add 10.0.0.2/24 dev namespace2-netns
    ```
    
    ```
    Kiểm tra:
    sudo ip netns exec namespace1 ip a
    ```
- Ping:
    ```
    sudo ip netns exec namespace1 ping 10.0.0.2
    ```
    ###### Kết quả:
    ![Getting Started](./image/result_lab.png)



