# Python
## 1. Data
### 1.1. Number
```
>>> 2 + 2
4
>>> 50 - 5*6
20
>>> (50 - 5*6) / 4
5.0
>>> 8 / 5  # division always returns a floating point number
1.6
```
### 1.2. String
```
>>> print('"Isn\'t," they said.')
"Isn't," they said.
>>> s = 'First line.\nSecond line.'  # \n means newline
>>> s  # without print(), \n is included in the output
'First line.\nSecond line.'
```
```
>>> # 3 times 'un', followed by 'ium'
>>> 3 * 'un' + 'ium'
'unununium'
```
```
>>> word = 'Python'
>>> word[0]  # character in position 0
'P'
>>> word[5]  # character in position 5
'n'
```
### 1.3. List 
```
>>> squares = [1, 4, 9, 16, 25]
>>> squares
[1, 4, 9, 16, 25]
```
```
>>> squares[0]  # indexing returns the item
1
>>> squares[-1]
25
>>> squares[-3:]  # slicing returns a new list
[9, 16, 25]
```
## 2. Control Flow Tools
### 2.1. if Statements
```
>>> x = int(input("Please enter an integer: "))
Please enter an integer: 42
>>> if x < 0:
...     x = 0
...     print('Negative changed to zero')
... elif x == 0:
...     print('Zero')
... elif x == 1:
...     print('Single')
... else:
...     print('More')
...
More
```
### 2.2. for Statements
```
>>> # Measure some strings:
... words = ['cat', 'window', 'defenestrate']
>>> for w in words:
...     print(w, len(w))
...
cat 3
window 6
defenestrate 12
```
```
# Strategy:  Iterate over a copy
for user, status in users.copy().items():
    if status == 'inactive':
        del users[user]

# Strategy:  Create a new collection
active_users = {}
for user, status in users.items():
    if status == 'active':
        active_users[user] = status
```
### 2.3. The ```range()``` Function
```
>>> for i in range(5):
...     print(i)
...
0
1
2
3
4
```
```
>>> list(range(5, 10))
[5, 6, 7, 8, 9]

>>> list(range(0, 10, 3))
[0, 3, 6, 9]

>>> list(range(-10, -100, -30))
[-10, -40, -70]
```
### 2.4. break and continue Statements, and else Clauses on Loops
- break
- continue
### 2.5. pass Statements
- The pass statement does nothing.
```
>>> while True:
...     pass  # Busy-wait for keyboard interrupt (Ctrl+C)
...
```
```
>>> class MyEmptyClass:
...     pass
...
```
```
>>> def initlog(*args):
...     pass   # Remember to implement this!
...
```
### 2.6. Defining Functions
eg.
```
>>> def fib(n):    # write Fibonacci series up to n
...     """Print a Fibonacci series up to n."""
...     a, b = 0, 1
...     while a < n:
...         print(a, end=' ')
...         a, b = b, a+b
...     print()
...
>>> # Now call the function we just defined:
... fib(2000)
0 1 1 2 3 5 8 13 21 34 55 89 144 233 377 610 987 1597
```
### 2.7. More on Defining Functions
#### 2.7.1. Default Argument Values 
<https://docs.python.org/3/tutorial/controlflow.html#default-argument-values>
#### 2.7.2. Keyword Arguments
<https://docs.python.org/3/tutorial/controlflow.html#keyword-arguments>

```
def cheeseshop(kind, *arguments, **keywords):
    print("-- Do you have any", kind, "?")
    print("-- I'm sorry, we're all out of", kind)
    for arg in arguments:
        print(arg)
    print("-" * 40)
    for kw in keywords:
        print(kw, ":", keywords[kw])
```
```
cheeseshop("Limburger", "It's very runny, sir.",
           "It's really very, VERY runny, sir.",
           shopkeeper="Michael Palin",
           client="John Cleese",
           sketch="Cheese Shop Sketch")
```
```
-- Do you have any Limburger ?
-- I'm sorry, we're all out of Limburger
It's very runny, sir.
It's really very, VERY runny, sir.
----------------------------------------
shopkeeper : Michael Palin
client : John Cleese
sketch : Cheese Shop Sketch
```
#### 2.7.3. Special parameters
```
def f(pos1, pos2, /, pos_or_kwd, *, kwd1, kwd2):
      -----------    ----------     ----------
        |             |                  |
        |        Positional or keyword   |
        |                                - Keyword only
         -- Positional only
```
#### 2.7.4. Lambda Expressions
<https://docs.python.org/3/tutorial/controlflow.html#lambda-expressions>
```
>>> def make_incrementor(n):
...     return lambda x: x + n
...
>>> f = make_incrementor(42)
>>> f(0)
42
>>> f(1)
43
```
result:
```
>>> pairs = [(1, 'one'), (2, 'two'), (3, 'three'), (4, 'four')]
>>> pairs.sort(key=lambda pair: pair[1])
>>> pairs
[(4, 'four'), (1, 'one'), (3, 'three'), (2, 'two')] 
```
#### 2.7.4. Documentation Strings
```
>>> def my_function():
...     """Do nothing, but document it.
...
...     No, really, it doesn't do anything.
...     """
...     pass
...
>>> print(my_function.__doc__)
Do nothing, but document it.

    No, really, it doesn't do anything.
```
#### 2.7.5. Function Annotations
<https://docs.python.org/3/tutorial/controlflow.html#function-annotations>
```
>>> def f(ham: str, eggs: str = 'eggs') -> str:
...     print("Annotations:", f.__annotations__)
...     print("Arguments:", ham, eggs)
...     return ham + ' and ' + eggs
...
>>> f('spam')
Annotations: {'ham': <class 'str'>, 'return': <class 'str'>, 'eggs': <class 'str'>}
Arguments: spam eggs
'spam and eggs'
```
## 3. Data Structures
### 3.1 More on Lists
- list.append(x): Add an item to the end of the list.
- list.extend(iterable):Extend the list by appending all the items from the iterable.
- list.insert(i, x): Insert an item at a given position.
- list.remove(x): Remove the first item from the list whose value is equal to x.
- list.pop(): removes and returns the last item in the list. 
- list.clear(): Remove all items from the list. 
- list.index(x[, start[, end]]): 
- list.count(x)
- list.sort(*, key=None, reverse=False)
- list.reverse()
- list.copy()
<https://docs.python.org/3/tutorial/datastructures.html#more-on-lists>

### 3.2. The del statement
```
>>> a = [-1, 1, 66.25, 333, 333, 1234.5]
>>> del a[0]
>>> a
[1, 66.25, 333, 333, 1234.5]
>>> del a[2:4]
>>> a
[1, 66.25, 1234.5]
>>> del a[:]
>>> a
[]
```
### 3.3. Tuples and Sequences
<https://docs.python.org/3/tutorial/datastructures.html#tuples-and-sequences>
### 3.4. Set
```
...
>>> a = set('abracadabra')
>>> b = set('alacazam')
>>> a                                  # unique letters in a
{'a', 'r', 'b', 'c', 'd'}
>>> a - b                              # letters in a but not in b
{'r', 'd', 'b'}
```
### 3.5. Dictionaries
<https://docs.python.org/3/tutorial/datastructures.html#dictionaries>
### 3.6. Looping Techniques
```
>>> import math
>>> raw_data = [56.2, float('NaN'), 51.7, 55.3, 52.5, float('NaN'), 47.8]
>>> filtered_data = []
>>> for value in raw_data:
...     if not math.isnan(value):
...         filtered_data.append(value)
...
>>> filtered_data
[56.2, 51.7, 55.3, 52.5, 47.8]

```
<https://docs.python.org/3/tutorial/datastructures.html#looping-techniques>
### 3.7. More on Conditions
<https://docs.python.org/3/tutorial/datastructures.html#more-on-conditions>
### 3.8. Comparing Sequences and Other Types
<https://docs.python.org/3/tutorial/datastructures.html#comparing-sequences-and-other-types>

## 4. Modules
### 4.1. More on Modules
```
#file fibo.py
# Fibonacci numbers module

def fib(n):    # write Fibonacci series up to n
    a, b = 0, 1
    while a < n:
        print(a, end=' ')
        a, b = b, a+b
    print()

def fib2(n):   # return Fibonacci series up to n
    result = []
    a, b = 0, 1
    while a < n:
        result.append(a)
        a, b = b, a+b
    return result
```
eg:
```
#import function fib, fib2 from file fibo.py
from fibo import fib, fib2 

# import all function form file fibo.py
from fibo import * 

# import fibo and rename as fib
import fibo as fib  

#import function fib form file fibo.py and rename as fibonacci 
from fibo import fib as fibonacci
```
### 4.1.1. Executing modules as scripts
```
python fibo.py <arguments>
```
```
# adding this code at the end of your module
if __name__ == "__main__":
    import sys
    fib(int(sys.argv[1]))
```
```
#eg:
python fibo.py 50
0 1 1 2 3 5 8 13 21 34
```
### 4.1.2. [The Module Search Path](https://docs.python.org/3/tutorial/modules.html#the-module-search-path)

### 4.1.3. [“Compiled” Python files](https://docs.python.org/3/tutorial/modules.html#compiled-python-files)

## 4.2. [Standard Modules](https://docs.python.org/3/tutorial/modules.html#standard-modules)

## 4.3. [The dir() Function](https://docs.python.org/3/tutorial/modules.html#the-dir-function)
```
>>> a = [1, 2, 3, 4, 5]
>>> import fibo
>>> fib = fibo.fib
>>> dir()
['__builtins__', '__name__', 'a', 'fib', 'fibo', 'sys']
```
## 4.4. Packages
```
sound/                          Top-level package
      __init__.py               Initialize the sound package
      formats/                  Subpackage for file format conversions
              __init__.py
              wavread.py
              wavwrite.py
              aiffread.py
              aiffwrite.py
              auread.py
              auwrite.py
              ...
      effects/                  Subpackage for sound effects
              __init__.py
              echo.py
              surround.py
              reverse.py
              ...
      filters/                  Subpackage for filters
              __init__.py
              equalizer.py
              vocoder.py
              karaoke.py
              ...
```
```
# import module echo.py from subpackage formats
import sound.effects.echo
# load function
sound.effects.echo.echofilter(input, output, delay=0.7, atten=4)
```

```
from sound.effects import echo
echo.echofilter(input, output, delay=0.7, atten=4)
```
```
from sound.effects.echo import echofilter
echofilter(input, output, delay=0.7, atten=4)
```
- if the file ```sound/effects/__init__.py``` could contain the following code:
```
__all__ = ["echo", "surround", "reverse"]
```
then
```
from sound.effects import *

```
would import the three named submodules of the sound package.
## 5. Errors and Exceptions
### 5.1. Syntax Errors
```
>>> while True print('Hello world')
  File "<stdin>", line 1
    while True print('Hello world')
                   ^
SyntaxError: invalid syntax
```
### 5.2. Exceptions
```
>>> 10 * (1/0)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ZeroDivisionError: division by zero
>>> 4 + spam*3
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'spam' is not defined
>>> '2' + 2
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: Can't convert 'int' object to str implicitly
```
### 5.3. Handling Exceptions
```
>>> while True:
...     try:
...         x = int(input("Please enter a number: "))
...         break
...     except ValueError:
...         print("Oops!  That was no valid number.  Try again...")
...
```
```
class B(Exception):
    pass

class C(B):
    pass

class D(C):
    pass

for cls in [B, C, D]:
    try:
        raise cls()
    except D:
        print("D")
    except C:
        print("C")
    except B:
        print("B")
```
### 5.4. Raising Exceptions
- The raise statement allows the programmer to force a specified exception to occur.
```
>>> raise NameError('HiThere')
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: HiThere
```
```
raise ValueError  # shorthand for 'raise ValueError()'  
```
```
>>> try:
...     raise NameError('HiThere')
... except NameError:
...     print('An exception flew by!')
...     raise
...
An exception flew by!
Traceback (most recent call last):
  File "<stdin>", line 2, in <module>
NameError: HiThere
```
### 5.5. [Exception Chaining](https://docs.python.org/3/tutorial/errors.html#exception-chaining)
```
#exc must be exception instance or None.
raise RuntimeError from exc
```
example:
```
>>> def func():
...     raise IOError
...
>>> try:
...     func()
... except IOError as exc:
...     raise RuntimeError('Failed to open database') from exc
...
Traceback (most recent call last):
  File "<stdin>", line 2, in <module>
  File "<stdin>", line 2, in func
OSError

The above exception was the direct cause of the following exception:

Traceback (most recent call last):
  File "<stdin>", line 4, in <module>
RuntimeError: Failed to open database
```
```
try:
    open('database.sqlite')
except OSError:
    raise RuntimeError from None

Traceback (most recent call last):
  File "<stdin>", line 4, in <module>
RuntimeError
```
### 5.6. [User-defined Exceptions](https://docs.python.org/3/tutorial/errors.html#user-defined-exceptions)
### 5.7. [Defining Clean-up Actions](https://docs.python.org/3/tutorial/errors.html#defining-clean-up-actions)
```
>>> try:
...     raise KeyboardInterrupt
... finally:
...     print('Goodbye, world!')
...
Goodbye, world!
KeyboardInterrupt
Traceback (most recent call last):
  File "<stdin>", line 2, in <module>
```
## 6. Classes
##### Different scopes and namespaces, and how global and nonlocal:
```
def scope_test():
    def do_local():
        spam = "local spam"

    def do_nonlocal():
        nonlocal spam
        spam = "nonlocal spam"

    def do_global():
        global spam
        spam = "global spam"

    spam = "test spam"
    do_local()
    print("After local assignment:", spam)
    do_nonlocal()
    print("After nonlocal assignment:", spam)
    do_global()
    print("After global assignment:", spam)

scope_test()
print("In global scope:", spam)
```
result:
```
After local assignment: test spam
After nonlocal assignment: nonlocal spam
After global assignment: nonlocal spam
In global scope: global spam
```
##### Class Definition Syntax
```
class ClassName:
    <statement-1>
    .
    .
    .
    <statement-N>
```
##### Class and Instance Variables
```
class Dog:

    kind = 'canine'         # class variable shared by all instances

    def __init__(self, name):
        self.name = name    # instance variable unique to each instance

>>> d = Dog('Fido')
>>> e = Dog('Buddy')
>>> d.kind                  # shared by all dogs
'canine'
>>> e.kind                  # shared by all dogs
'canine'
>>> d.name                  # unique to d
'Fido'
>>> e.name                  # unique to e
'Buddy'
```
```
class Dog:

    def __init__(self, name):
        self.name = name
        self.tricks = []    # creates a new empty list for each dog

    def add_trick(self, trick):
        self.tricks.append(trick)

>>> d = Dog('Fido')
>>> e = Dog('Buddy')
>>> d.add_trick('roll over')
>>> e.add_trick('play dead')
>>> d.tricks
['roll over']
>>> e.tricks
['play dead']
```

##### Random Remarks

## 7. [virtualenv](https://docs.python.org/3/tutorial/venv.html)